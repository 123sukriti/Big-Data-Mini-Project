// routes/user.js
const express = require('express');
const User = require('../models/User');
const nodemailer = require('nodemailer');

const router = express.Router();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-email-password',
  },
});

router.post('/signup', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();

    const mailOptions = {
      from: 'your-email@gmail.com',
      to: user.email,
      subject: 'Signup Confirmation',
      text: 'Thanks for signing up!',
    };

    transporter.sendMail(mailOptions);
    res.status(201).send({ message: 'User registered and email sent' });
  } catch (error) {
    res.status(400).send(error);
  }
});

module.exports = router;
