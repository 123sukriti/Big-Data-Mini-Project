// routes/booking.js
const express = require('express');
const Booking = require('../models/Booking');
const sendMessage = require('../producer'); // Kafka producer
const nodemailer = require('nodemailer');

const router = express.Router();

router.post('/book', async (req, res) => {
  try {
    const booking = new Booking(req.body);
    await booking.save();

    // Send booking data to Kafka
    await sendMessage('bookings', booking);

    // Send booking confirmation email
    const mailOptions = {
      from: 'your-email@gmail.com',
      to: req.body.email,
      subject: 'Booking Confirmation',
      text: `Your booking for ${req.body.service} is confirmed!`,
    };

    transporter.sendMail(mailOptions);
    res.status(201).send({ message: 'Booking confirmed and email sent' });
  } catch (error) {
    res.status(400).send(error);
  }
});

module.exports = router;
